//
//  ViewController.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 09/06/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

