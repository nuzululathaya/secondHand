//
//  ProductModel.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 27/06/22.
//

import Foundation
import Alamofire

class ProductResponse: Codable {
   var response: [ProductInfo]
}


struct ProductInfo: Codable, Hashable {
    let id: Int
    let name: String?
    let description: String?
    let base_price: Int?
    let image_url: String?
    let image_name: String?
    let location: String?
    let user_id: Int?
    let status: String?
    let createdAt: String?
    let updatedAt: String?
    let Categories: [Category?]
}


struct Category: Codable, Hashable {
    let id: Int
    let name: String
}


class categoryResponse: Codable {
   var response: [CategoryInfo]
}


struct CategoryInfo: Codable, Hashable {
   
    let id: Int
    var name: String?
    let createdAt: String?
    let updatedAt: String?
}


