//
//  CategoryModel.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 13/07/22.
//

import Foundation

class CategoryResponse: Codable {
   var response: [CategoryResponseInfo]
}


struct CategoryResponseInfo: Codable, Hashable {
   
    let id: Int
    let name: String?
    let createdAt: String?
    let updatedAt: String?
                                    
}

struct ProductDetailInfo: Codable, Hashable {
    let id: Int?
    let name: String?
    let description: String?
    let base_price: Int?
    let image_url: String?
    let image_name: String?
    let location: String?
    let user_id: Int?
    let status: String?
    let createdAt: String?
    let updatedAt: String?
    let Categories: [Category]
    let userinfo: UserInfo?
}




struct UserInfo: Codable, Hashable {
    let id: Int?
    let full_name: String?
    let email: String?
    let phone_number: String?
    let address: String?
    let image_url: String?
    let city: String?
}
