//
//  TabBar.swift
//  secondHand
//
//  Created by nurin berlianna on 30/06/22.
//

import SwiftUI

struct TabBar: View {
    var body: some View {
        
        TabView {
    
            HomeScreen()
                .tabItem {
                    Label("Home", systemImage: "house")
                }
               
            NotificationScreen()
                .tabItem {
                    Label("Notification", systemImage: "bell")
                }
            AddScreen()
                .tabItem {
                    Label("Jual", systemImage: "plus.circle")
                }
            ListSaleScreen()
                .tabItem {
                    Label("Daftar Jual", systemImage: "list.bullet")
                }
            AccountView()
                .tabItem {
                    Label("Akun", systemImage: "person")
                }
        }
        .accentColor(Color("Primary"))
    }
}

            

struct TabBar_Previews: PreviewProvider {
    static var previews: some View {
        TabBar()
    }
}
//
//struct BottomNavBarItem: View {
//    let image: Image
//    let action: ()-> Void
//    var body: some View {
//        Button(action: action, label: {
//            image
//                .frame(maxWidth: .infinity)
//        })
//    }
//}
    

