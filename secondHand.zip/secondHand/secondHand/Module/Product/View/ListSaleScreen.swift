//
//  ListSaleScreen.swift
//  secondHand
//
//  Created by nurin berlianna on 04/07/22.
//

import SwiftUI


var tabs = ["Produk", "Diminati", "Terjual"]
struct ListSaleScreen: View {
    @State var selectedTab = tabs[0]
    @Namespace var animation
    var body: some View {
        NavigationView {
            ScrollView {
            ZStack {
                
                VStack  {
    
                    ProfileView()
                        
                }
            }
        ScrollView (.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(tabs, id: \.self) { tab in
                            SellerButton(text: tab, selected: $selectedTab, animation: animation)
                        }
                    }
                    .padding(.vertical, 24)
                    
        }
                
                HStack {
                NavigationLink(destination: DetaiProdukJual()) {
        
                    Image("Tambah")
                        .resizable()
                        .frame(width: 156, height: 206, alignment: .leading)
                        .scaledToFit()
                        
                    
                    
                }
                .navigationTitle("Daftar Jual")
                .padding()
                    Spacer()
                }
        }
    }
}

        
    struct SellerButton: View {
        var text : String
        @Binding var selected: String
        var animation: Namespace.ID
        var body: some View {
            
            Button(action: {
                withAnimation(.spring(), {
                    selected = text
                })
            }) {
                Text(text)
                    .fontWeight(.medium)
                    .foregroundColor(selected == text ? .white : .black)
                    .padding()
                    .padding(.horizontal)
                    .background(ZStack {
                        if (selected == text) {
                            Color("Primary")
                                .cornerRadius(12)
                                .matchedGeometryEffect(id: "Tab", in: animation)
                            
                            
                        }
                    })
                    .cornerRadius(12)
                    .shadow(color: Color.black.opacity(0.16), radius: 16, x: 4, y: 4)
            }
            
        }
    }

struct ListSaleScreen_Previews: PreviewProvider {
    static var previews: some View {
        ListSaleScreen()
    }
}


}

struct ProfileView: View {
    var body: some View {
        HStack {
            Image("Profile")
                .resizable()
                .frame(width: 50, height: 50, alignment: .leading)
                .cornerRadius(12.0)
                .scaledToFit()
            
            VStack (alignment: .leading, spacing: 4) {
                Text("Nama Penjual")
                    .font(.custom("Poppins-SemiBold", size: 14))
                    .frame(alignment: .topTrailing)
                Text("Kota")
                    .font(.custom("Poppins", size: 10))
                    .foregroundColor(.secondary)
                    .frame(alignment: .topTrailing)
            }
            
            Spacer()
            NavigationLink(destination: UbahAkunView()) {
                Image("edit")
                    .resizable()
                    .frame(width: 50, height: 26, alignment: .leading)
                    .scaledToFit()
            }
            
        }
        .frame(maxWidth: 328, maxHeight: .infinity)
        .padding()
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 1)
    }
}
