//
//  ProductViewScreen.swift
//  secondHand
//
//  Created by nurin berlianna on 07/07/22.
//

import SwiftUI
import Alamofire
import SDWebImageSwiftUI
import HalfASheet

struct ProductViewScreen: View {
    @State private var isShowing = false
    @State private var amount = 0.0
    @State private var ttext: String = ""
    
    let item: Int?
    @State var results = ProductDetailInfo(id: 0, name: "", description: "", base_price: 0, image_url: "", image_name: "", location: "", user_id: 0, status: "", createdAt: "", updatedAt: "", Categories: [Category(id: 0, name: "")], userinfo: UserInfo(id: 0, full_name: "", email: "", phone_number: "", address: "", image_url: "", city: ""))
    
    func loadData(id: Int = 1341) {
        
           AF.request("https://market-final-project.herokuapp.com/buyer/product/\(id)")
                  .responseData { response in

                   switch response.result {
                       case let .success(value):

                           do {
                               let decoder = JSONDecoder()
                               let model = try decoder.decode(ProductDetailInfo.self, from: value)
                               
                               self.results = model
                            
                               
                               print(self.results)
                               
                           } catch {
                               print("Error", error)
                       }

                       case let .failure(error): print(error)
                   }

               }
        }
        var body: some View {
            GeometryReader { geometry in
                ZStack(alignment: .bottom, content: {
                    ScrollView(.vertical){
                        VStack(alignment: .leading) {
                            WebImage(url: URL(string: results.image_url ?? "" ))// .customLoopCount(1) // Custom loop count
                                .playbackRate(2.0) // Playback speed rate
                                .playbackMode(.bounce) // Playback normally to the end, then reversely back to the start
                                // `WebImage` supports advanced control just like `AnimatedImage`, but without the progressive animation support
                                .resizable()
                                .aspectRatio(contentMode: .fit)
        //                        .ignoresSafeArea(.all)
                                .edgesIgnoringSafeArea(.top)
                                .scaledToFill()
                                .scaledToFit()
                                .padding()
                            
                            
                            ProductInformation(
                                title: results.name ?? "",
                                category: results.description ?? "",
                                base_price: results.base_price ?? 0,
                                description: results.description ?? ""
                            )
                            
                        }
                        
                        
                    }
                })
                VStack(alignment: .center) {
                    Spacer()
                    HStack {
                        Spacer()
                 Button("Saya Tertarik dan Ingin Nego") {
                     isShowing.toggle()
                 }
                 .padding()
                 .font(.custom("Poppins-Regular", size: 14))
                 .foregroundColor(Color.white)
                 .background(Color("Primary"))
                 .cornerRadius(18.0)
                 
                        Spacer()
                    }
                    .background(Color("Primary"))
                    .cornerRadius(18.0)
                    .padding()
                }
                 HalfASheet(isPresented: $isShowing, title: "Maukan Harga Tawarmu") {
                     ScrollView {
                     VStack(alignment:.center ,spacing: 24) {
                         Spacer()
                         Text("Harga tawaranmu akan diketahui penual, jika penjual cocok kamu akan segera dihubungi penjual.")
                            
                             .font(.system(size: 14))
                             .foregroundColor(Color.secondary)
                             
                         HStack {
                             Image("casio_1")
                                 .resizable()
                                 .scaledToFit()
                                 .frame(width: 50, height: 50)
                                 .cornerRadius(16.0)
                             
                             VStack (alignment: .leading, spacing: 10) {
                                 Text("jam tangan casio")
                                     .font(.system(size: 14))
                                     .bold()
                                     
                                 Text("Rp 250.000")
                                     .font(.system(size: 14))
                                     .foregroundColor(Color.black)
                             }
                           Spacer()
                         }
                         .padding()
                         .background(Color.white)
                         .cornerRadius(16.0)
                         .shadow(radius: 2)
                         
                         VStack(alignment: .leading, spacing: 4){
                             
                             Text("Harga Tawar")
                             TextField("Rp 0,00", text: $ttext)
                                 .font(.custom("Poppins-Regular", size: 14))
                                 .padding()
                                 .background(Color.white)
                                 .cornerRadius(16.0)
                                 .shadow(radius: 1)
                         }
                     }
                     .padding()
                    }
                         VStack {
                             Spacer()
                             HStack {
                         Spacer()
                         Button(action: {}) {
                             Text("Kirim")
                                 .foregroundColor(Color.white)
                                 .background(Color("Primary"))
                                
                         }
                         .padding()
                         .font(.custom("Poppins-Regular", size: 14))
                         .foregroundColor(Color.white)
                         .background(Color("Primary"))
                         .cornerRadius(18.0)
                        
                                Spacer()
                            }
                          
                            .background(Color("Primary"))
                            .cornerRadius(18.0)
                           
                             
                         
                     }
                     .frame(maxWidth: 296, maxHeight: .infinity)
                     
                 }
                 // Customise by editing these.
                 .height(.proportional(0.60))
                 .closeButtonColor(UIColor.white)
                 .backgroundColor(.white)
                 .contentInsets(EdgeInsets(top: 30, leading: 10, bottom: 30, trailing: 10))
                 .cornerRadius(16)
                
                
                
                    .onAppear {
                        self.loadData(id: item ?? 1341)
                    }
            }
    }

}


struct ProductViewScreen_Previews: PreviewProvider {
    static var previews: some View {
        ProductViewScreen(item: 1314)
    }
}


struct ProductInformation: View {
    let title: String
    let category: String
    let base_price: Int
    let description: String
    
    var body: some View {
        VStack (alignment: .center, spacing: 10) {
            
            HStack {
            VStack(alignment: .leading, spacing: 10.0) {
                Text("\(title)")
                    .font(.system(size: 18))
                    .foregroundColor(Color.black)
                    .bold()
                    .frame(alignment: .topTrailing)
      
                Text("\(category)")
                    .font(.system(size: 16))
                    .foregroundColor(.secondary)
                    .frame(alignment: .leading)
             
                Text("\(base_price)")
                    .font(.system(size: 18))
                    .foregroundColor(.black)
                    .multilineTextAlignment(.leading)
                    .frame(alignment: .bottom)
                              
                }
                Spacer()
            }
            .frame(alignment: .bottom)
            .padding()
            .background(Color.white)
            .cornerRadius(16.0)
            .shadow(radius: 2)
            
            
            HStack {
                Image("Profile")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 50, height: 50, alignment: .leading)
                    .cornerRadius(16.0)
                
                VStack (alignment: .leading, spacing: 10) {
                    Text("Nama Penjual")
                        .font(.system(size: 18))
                        .bold()
                        .frame(alignment: .topTrailing)
                    
                    Text("kota")
                        .font(.system(size: 16))
                        .foregroundColor(.secondary)
                        .frame(alignment: .topTrailing)
                 
                }
              Spacer()
            }
            .padding()
            .background(Color.white)
            .cornerRadius(16.0)
            .shadow(radius: 2)
            
            HStack {
            VStack(alignment: .leading, spacing: 10.0) {
                Text("Deskripsi")
                    .font(.system(size: 18))
                    .bold()
                    .frame(alignment: .topTrailing)
      
                Text("\(description)")
                    .font(.system(size: 16))
                    .foregroundColor(.secondary)
                    .frame(alignment: .leading)
                                           
                }
                Spacer()
            }
            .frame(alignment: .bottom)
            .padding()
            .background(Color.white)
            .cornerRadius(16.0)
            .shadow(radius: 2)
        
            
        }
        .padding()
        .frame(alignment: .top)
        .background(.white)
        
        
    }
}
