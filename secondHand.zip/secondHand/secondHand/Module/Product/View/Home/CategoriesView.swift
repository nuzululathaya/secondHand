//
//  CategoriesView.swift
//  final project
//
//  Created by nurin berlianna on 25/06/22.
//

import Foundation
import SwiftUI
import Alamofire


class CategoryViewModel: ObservableObject {
    @Published var results = [CategoryResponseInfo]()
//    var callback: (_ name: String) -> Void?
    
    func loadCategories() {
        AF.request("https://market-final-project.herokuapp.com/seller/category")
               .responseData { response in

                switch response.result {
                    case let .success(value):
                    

                        do {
                            let decoder = JSONDecoder()
                            let model = try decoder.decode([CategoryResponseInfo].self, from: value)
//                            print(model)
                            for item in model {
                                self.results.append(item)
                            }
//                            self.results = model
//                            model.forEach { CategoryInfo in model
//                                print(CategoryInfo)
//                                self.tabsCompleted.append(CategoryInfo)
//                                self.tabs.append(CategoryInfo.name!)
//
//                            }
                            
//                            print(self.tabsCompleted)
                          
                        
                        } catch {
                            print("Error", error)
                    }

                    case let .failure(error): print(error)
                }

            }
     
    }
}


struct CategoriesView: View {
    @StateObject var viewModel = CategoryViewModel()
    
    @State var selectedTab = ""
    @State var selectedTabID: Int = 0
    @Namespace var animation
    var calback: (_ id: Int) -> Void?
    
    var body: some View {
        ScrollView (.horizontal, showsIndicators: false) {
            HStack {
                
                ForEach(self.viewModel.results, id: \.self) { tab in
                    CategoryButton(
                        text: tab.name ?? "",
                        selected: $selectedTab,
                        animation: animation, calback: {
                            return calback(tab.id ?? 0)
                        }
                    )
                }
              
            }
        }
        .padding()
            .onAppear {
                let item = CategoryResponseInfo(id: 0, name: "ALL", createdAt: "", updatedAt: "")
                self.viewModel.results.append(item)
                self.selectedTab = item.name ?? "ALL"
                DispatchQueue.main.asyncAfter(deadline: .now()) {
                    self.viewModel.loadCategories()
                }
            }
    }
}

struct CategoryButton: View {
    var text : String
    @Binding var selected: String
    var animation: Namespace.ID
    var calback: () -> Void?
    
    var body: some View {
        Button(action: {
            withAnimation(.spring(), {
                selected = text
                calback()
            })
        }) {
            Text(text)
                .fontWeight(.medium)
                .foregroundColor(selected == text ? .white : .black)
                .padding()
                .background(ZStack {
                    if (selected == text) {
                        Color("Primary")
                            .cornerRadius(12)
                            .matchedGeometryEffect(id: "Tab", in: animation)
                        
                    }
                })
                .cornerRadius(12)
                .shadow(color: Color.black.opacity(0.16), radius: 16, x: 4, y: 4)
        }
        
    }
}

