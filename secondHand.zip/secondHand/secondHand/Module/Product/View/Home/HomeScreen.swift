//
//  HomeScreen.swift
//  secondHand
//
//  Created by nurin berlianna on 04/07/22.
//

import SwiftUI
import Alamofire
import SDWebImageSwiftUI

struct HomeScreen: View {
    @State var count = 0
    @State var results = [ProductInfo]()
    
    private let columns: [GridItem] = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
       
    func loadData(catId: Int = 0, search: String = "") {
        var id = ""
        switch catId {
        case 0:
            id = ""
        default:
            id = "\(catId)"
        }
        
           AF.request("https://market-final-project.herokuapp.com/buyer/product?status=available&category_id=\(id)&search=\(search)&page=1&per_page=30")
                  .responseData { response in

                   switch response.result {
                       case let .success(value):

                           do {
                               let decoder = JSONDecoder()
                               let model = try decoder.decode([ProductInfo].self, from: value)
//                               print(model)
                               self.results = model
                               
                           } catch {
                               print("Error", error)
                       }

                       case let .failure(error): print(error)
                   }

               }
        
       }
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color("bck"),
                Color.white]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()
        
            ScrollView {
                VStack (alignment: .leading){
                    SearchView { search in
                        return loadData(catId: 0, search: search)
                    }
                    
                    TagLineView()
                        .padding()
                    
                    CategoriesView { id in
                        return loadData(catId: id)
                        print("callback with id: \(id)")
                    }

                    
                    ScrollView {
                        LazyVGrid (columns: columns,
                        spacing: 1
                        ) {
                            
                        ForEach(results, id: \.self) {
                            
                            item in
                            NavigationLink(destination: ProductViewScreen(item: item.id)) {
                                ProductCardView(url: item.image_url ?? "", size: 210, name: item.name ?? "", price: item.base_price ?? 0, description: item.description ?? "", Id: item.id)
                                }
                            }
                          
                        }
                    }
                }
            }
            
        }
            .onAppear {
                loadData()
            }
}
    struct HomeScreen_Previews: PreviewProvider {
        static var previews: some View {
            HomeScreen()
        }
    }
   
    struct SearchView: View {
        @State private var searchableString = ""
        var calback: (_ search: String) -> Void?
        
        var body: some View {
           
            HStack {
                HStack {
                    Image("Search")
                        .padding(.trailing, 8)
                    TextField("Search", text: $searchableString)
                        .foregroundColor(.black)
                        .onChange(of: searchableString) { newValue in
                            DispatchQueue.main.asyncAfter(deadline: .now() + 2, execute:  {
                                print(newValue)
                                self.calback(newValue)
                            })
                        }
                }
                .padding(.all, 20)
                .background(Color.white)
                .cornerRadius(16.0)
                .padding(.trailing)
                
            }
                .padding(.horizontal)
            }
         
        }

    struct TagLineView: View {
        var body: some View {
            
            HStack {
            VStack(alignment: .leading, spacing: 16){
                
                Text("Bulan Ramadhan \nBanyak ")
                    .font(.custom("Poppins-SemiBold", size: 19))
                    .foregroundColor(Color.black)
                + Text("Diskon!")
                    .font(.custom("Poppins-SemiBoldItalic", size: 19))
                    .foregroundColor(Color.black)

                VStack(alignment: .leading, spacing: 4) {
                Text("Diskon Hingga")
                    .font(.custom("Poppins-Regular", size: 10))
                Text("60%")
                    .font(.custom("Poppins-Regular", size: 18))
                    .bold()
                    .foregroundColor(Color.red)
                    
                }
                Spacer()
                Text("Telusuri Kategori")
                    .font(.custom("Poppins-Regular", size: 14))
                
                }
                
                Spacer()
               Button(action: {}) {
                    Image("gift")
                        .resizable()
                        .frame(width: 127, height: 123)
                        .cornerRadius(5.0)
  
        
               }
            }
            
        }
      
    }

    struct ProductCardView: View {
        let url: String
        let size: CGFloat
        let name: String
        let price: Int
        let description: String
        let Id: Int
        @State private var isActive: Bool = false
        
        var body: some View {
            NavigationLink(destination: ProductViewScreen(item: Id), isActive: $isActive) {
            VStack {
                WebImage(url: URL(string: url ))
              
                
                   .resizable()
                   .aspectRatio(contentMode: .fill)
                   .frame(width: 140, height: 100)
                   .ignoresSafeArea(.all)
                   .cornerRadius(4.0)
                   .shadow(radius: 2)
            
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(name)
                    .font(.custom("Poppins-Regular", size: 14))
                    .foregroundColor(Color.black)
                    .fontWeight(.bold)
                    .truncationMode(.tail)
                
                Text(description)
                    .font(.system(size: 10))
                    .foregroundColor(.secondary)
                    .truncationMode(.tail)
                    
            
                Text("Rp \(price)")
                    .font(.custom("Poppins-Regular", size: 14))
                    .foregroundColor(.black)
                    .truncationMode(.tail)
                    
                    
                    }
                    Spacer()
                }
            }
        }
            .onTapGesture{
                isActive = true
            }
            .frame(maxWidth: 156, maxHeight: 206)
            .padding()
            .background(Color.white)
            .cornerRadius(8.0)
            .shadow(radius: 3)
            .padding()
            
//            NavigationLink(destination: ProductViewScreen(item: Id), isActive: $isActive) { }
            
        }
    }
}


