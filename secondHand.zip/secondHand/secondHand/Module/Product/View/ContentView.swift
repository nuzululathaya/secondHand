//
//  ContentView.swift
//  secondHand
//
//  Created by nurin berlianna on 27/06/22.
//

import SwiftUI
import Alamofire


struct ContentView: View {
    var body: some View {
    
                TabBar()
                            
        }
    }


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewDevice("iPhone 13")
            .previewInterfaceOrientation( .portrait)
    }
}

