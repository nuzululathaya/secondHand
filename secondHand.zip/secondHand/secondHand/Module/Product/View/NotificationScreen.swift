//
//  NotificationScreen.swift
//  secondHand
//
//  Created by Zaki Dony Karensyah dan Nurin Berlianna on 14/07/22.
//

import SwiftUI
struct NotificationScreen: View
{
    var body: some View
    {
    
        NavigationView
        {
            VStack
            {
                PenawaranCard()
                BerhasilCard()
                Spacer()
                .navigationTitle("Notifikasi")
            }
        }
    }
}


struct Notification_Previews: PreviewProvider
{
    static var previews: some View
    {
        NotificationScreen()
    }
}

struct PenawaranCard: View
{
    var body: some View
    {
        HStack
        {
            VStack (alignment: .leading, spacing: 4)
            {
            Image("casio_1")
                .resizable()
                .frame(width: 50, height: 50, alignment: .leading)
                .cornerRadius(12.0)
                .scaledToFit()
            Spacer()
            }
            
            VStack (alignment: .leading, spacing: 4)
            {
                Text("Penawaran Produk")
                    .font(.custom("Poppins", size: 10))
                    .foregroundColor(.secondary)
                    .frame(alignment: .topTrailing)
                Text("Jam Tangan Casio")
                    .font(.custom("Poppins-Light", size: 14))
                    .frame(alignment: .topTrailing)
                Text("Rp. 250.000")
                    .font(.custom("Poppins-Light", size: 14))
                    .frame(alignment: .topTrailing)
                Text("Ditawar Rp. 200.000")
                    .font(.custom("Poppins-Light", size: 14))
                    .frame(alignment: .topTrailing)
            }
            Spacer()
            VStack
            {
                HStack
                {
                    Text("20 Apr, 14:04")
                        .font(.custom("Poppins", size: 10))
                        .foregroundColor(.secondary)
                        .frame(alignment: .topTrailing)
                    
                    Image("RedDot")
                        .resizable()
                        .frame(width: 8, height: 8, alignment: .top)
                        .cornerRadius(12.0)
                        .scaledToFit()
                }
                Spacer()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: 86)
        .padding()
        .background(Color.white)
        .shadow(radius: 1)
    }
}

struct BerhasilCard: View
{
    var body: some View
    {

        HStack
        {
            VStack (alignment: .leading, spacing: 4)
            {
            Image("casio_1")
                .resizable()
                .frame(width: 50, height: 50, alignment: .leading)
                .cornerRadius(12.0)
                .scaledToFit()
                Spacer()
            }
            
            VStack (alignment: .leading, spacing: 4)
            {
                Text("Berhasil Diterbitkan")
                    .font(.custom("Poppins", size: 10))
                    .foregroundColor(.secondary)
                    .frame(alignment: .topTrailing)
                Text("Jam Tangan Casio")
                    .font(.custom("Poppins-Light", size: 14))
                    .frame(alignment: .topTrailing)
                Text("Rp. 250.000")
                    .font(.custom("Poppins-Light", size: 14))
                    .frame(alignment: .topTrailing)
                Spacer()
            }
            Spacer()
            VStack
            {
                HStack
                {
                    Text("19 Apr, 12:00")
                        .font(.custom("Poppins", size: 10))
                        .foregroundColor(.secondary)
                        .frame(alignment: .topTrailing)
                    Image("RedDot")
                        .resizable()
                        .frame(width: 8, height: 8, alignment: .top)
                        .cornerRadius(12.0)
                        .scaledToFit()
                }
                Spacer()
            }
        }
        .padding()
    }
}
