//
//  AddScreen.swift
//  secondHand
//
//  Created by nurin berlianna on 04/07/22.
//

import SwiftUI

struct AddScreen: View
{
    var body: some View
    {
        NavigationView
        {
            ZStack
            {
                ScrollView
                {
                    informationProduct2()
        
                }
                    buttonProduct2()
            }
                .navigationBarTitle("Lengkapi Detail Produk", displayMode: .inline)
        }
    }
}


    

struct AddScreen_Previews: PreviewProvider
{
    static var previews: some View
    {
        AddScreen()
    }
}

struct informationProduct2: View {
@State private var ttext: String = ""
var body: some View {
    VStack(alignment: .leading, spacing: 16) {
        
        VStack(alignment: .leading, spacing: 4) {
            
            Text("Nama Produk")
                .font(.custom("Poppins-Regular", size: 12))
            
            TextField("Nama Produk", text: $ttext)
                .font(.custom("Poppins-Regular", size: 14))
                .padding()
                .background(Color.white)
                .cornerRadius(16.0)
//                .padding(.trailing)
                .shadow(radius: 1)
            
        }
        VStack(alignment: .leading, spacing: 4) {
            Text("Harga Produk")
                .font(.custom("Poppins-Regular", size: 12))
            
            TextField("Rp 0,00", text: $ttext)
                .font(.custom("Poppins-Regular", size: 14))
                .padding()
                .background(Color.white)
                .cornerRadius(16.0)
//                .padding(.trailing)
                .shadow(radius: 1)
            
        }
        
        VStack(alignment: .leading, spacing: 4) {
            Text("Pilih Kategori")
                .font(.custom("Poppins-Regular", size: 12))
            
            TextField("Pilih Kategori", text: $ttext)
                .font(.custom("Poppins-Regular", size: 14))
                .padding()
                .background(Color.white)
                .cornerRadius(16.0)
//                .padding(.trailing)
                .shadow(radius: 1)
        }
        
        VStack(alignment: .leading, spacing: 4) {
            Text("Deskripsi")
                .font(.custom("Poppins-Regular", size: 12))
            
            TextField("Contoh: Jalan Ikan Hiu 33", text: $ttext)
                .font(.custom("Poppins-Regular", size: 14))
                .frame(width: .infinity, height: 80)
                .padding()
                .background(Color.white)
                .cornerRadius(16.0)
//                .padding(.trailing)
                .shadow(radius: 1)
        }
        
        VStack(alignment: .leading, spacing: 4) {
            Text("Foto Produk")
                .font(.custom("Poppins-Regular", size: 12))
            
            Button(action: {}) {
            Image("plus")
                .resizable()
                .frame(maxWidth: 96, maxHeight: 96)
            }
            
        }
        Spacer()
        
    }
    .frame(maxWidth: .infinity)
    .padding()
}
}

struct buttonProduct2: View
{
    var body: some View
    {
        VStack
        {
            Spacer()
        
            HStack(alignment: .bottom, spacing: 16)
            {
                Button(action: {})
                {
                    Image("preview")
                        .resizable()
                        .frame(maxWidth: 156, maxHeight: 48)
                }
            
                Button(action: {})
                {
                    Image("terbit")
                        .resizable()
                        .frame(maxWidth: 156, maxHeight: 48)
                
                }
            }
        }
    }
}


//struct AddScreen: View {
//    var body: some View {
//        Text("empty")
//    }
//}
//
//
//struct AddScreen_Previews: PreviewProvider {
//    static var previews: some View {
//        AddScreen()
//    }
//}
//
