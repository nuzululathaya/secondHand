//
//  Seller25.swift
//  secondHand
//
//  Created by karen syah on 18/07/22.
//

import SwiftUI
import HalfASheet

struct Seller25: View {
    
    @State private var isShowing = false
    
    var body: some View {
        NavigationView {
                VStack  {
                    
                PenawarView()
            
                VStack {
                    HStack {
                        Text("Daftar Produkmu yang Ditawar")
                            .font(.custom("Poppins-SemiBold", size: 14))
                            .frame(alignment: .topTrailing)
                            .padding()
                        Spacer()
                    }

                        HStack  {
                            VStack (alignment: .leading, spacing: 4) {
                            Image("casio_1")
                                .resizable()
                                .frame(width: 50, height: 50, alignment: .leading)
                                .cornerRadius(12.0)
                                .scaledToFit()
                            Spacer()
                            }
                            
                            VStack (alignment: .leading, spacing: 4) {
                                Text("Penawaran Produk")
                                    .font(.custom("Poppins", size: 10))
                                    .foregroundColor(.secondary)
                                    .frame(alignment: .topTrailing)
                                Text("Jam Tangan Casio")
                                    .font(.custom("Poppins-Light", size: 14))
                                    .frame(alignment: .topTrailing)
                                Text("Rp. 250.000")
                                    .font(.custom("Poppins-Light", size: 14))
                                    .frame(alignment: .topTrailing)
                                Text("Ditawar Rp. 200.000")
                                    .font(.custom("Poppins-Light", size: 14))
                                    .frame(alignment: .topTrailing)
                                Spacer()
                            }
                            Spacer()
                            
                            HStack   {
                                VStack (alignment: .leading, spacing: 4) {
                                    Text("20 Apr, 14:04")
                                        .font(.custom("Poppins", size: 10))
                                        .foregroundColor(.secondary)
                                        .frame(alignment: .top)
                                    Spacer()
                                }
                            }
                        }
                        .frame(maxWidth: .infinity, maxHeight: 86)
                        .padding()
                
                }
 
                    HStack {
                        Button(action: {}){
                    
                            Image("Tolak")
                                .resizable()
                                .frame(width: 156, height: 36, alignment: .leading)
                                .cornerRadius(12.0)
                                .scaledToFit()
                        }
                        
                        Button(action: {isShowing.toggle()})
                        {
                            Image("Terima")
                                .resizable()
                                .frame(width: 156, height: 36, alignment: .leading)
                                .cornerRadius(12.0)
                                .scaledToFit()
                        }
                        
                        }
   
                HalfASheet(isPresented: $isShowing, title: "Yeay kamu berhasil mendapat harga yang sesuai") {
                    VStack(alignment:.leading ,spacing: 24) {
                        Text("Segera hubungi pembeli melalui whatsapp untuk transaksi selanjutnya")
                            .font(.system(size: 14))
                            .foregroundColor(Color.secondary)
                        VStack {
                            Text("Product Match")
                            
                            HStack {
                                Image("IU")
                                    .resizable()
                                    .frame(width: 50, height: 50, alignment: .leading)
                                    .cornerRadius(12.0)
                                    .scaledToFit()
                            
                                VStack (alignment: .leading, spacing: 4) {
                                    Text("Lee Ji-eun")
                                        .font(.custom("Poppins-SemiBold", size: 14))
                                        .frame(alignment: .topTrailing)
                                    Text("Songjeong-dong, Seoul")
                                        .font(.custom("Poppins", size: 10))
                                        .foregroundColor(.secondary)
                                        .frame(alignment: .topTrailing)
                                }
                                Spacer()
                            }

                            
                            HStack {
                                Image("casio_1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50, height: 50)
                                    .cornerRadius(12.0)
                                
                                VStack (alignment: .leading, spacing: 10) {
                                    Text("Jam tangan casio")
                                        .font(.custom("Poppins-Light", size: 14))
                                       
                                        
                                    Text("Rp 250.000")
                                        .font(.custom("Poppins-Light", size: 14))
                                        .strikethrough()
                                        .foregroundColor(Color.black)
                                    
                                    Text("Ditawar Rp 200.000")
                                        .font(.custom("Poppins-Light", size: 14))
                                        .foregroundColor(Color.black)
                                }
                              Spacer()
                            }

                        }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(16.0)
                            .shadow(radius: 2)

                        
                      

                        Button(action: {}) {
                            Image("Hubungi-1")
                                .resizable()
                                .frame(width: 296, height: 48, alignment: .leading)
                                .cornerRadius(16.0)
                                .scaledToFit()
                                .padding()
                            
                        }
                    }
                    .frame(maxWidth: 296, maxHeight: .infinity)
                    
                }

            }
                
                .navigationBarTitle("Info Penawar", displayMode: .inline)
            }

    }
}
struct Seller25_Previews: PreviewProvider {
    static var previews: some View {
        Seller25()
            .previewInterfaceOrientation(.portrait)
        
    }
}

struct PenawarView: View {
    var body: some View {
        HStack  {
            Image("IU")
                .resizable()
                .frame(width: 50, height: 50, alignment: .leading)
                .cornerRadius(12.0)
                .scaledToFit()
            
            VStack (alignment: .leading, spacing: 4) {
                Text("Lee Ji-eun")
                    .font(.custom("Poppins-SemiBold", size: 14))
                    .frame(alignment: .topTrailing)
                Text("Songjeong-dong, Seoul")
                    .font(.custom("Poppins", size: 10))
                    .foregroundColor(.secondary)
                    .frame(alignment: .topTrailing)
            }
            Spacer()
        }
        .padding()
        .frame(maxWidth: 328, maxHeight: 80)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 1)
    }
}
