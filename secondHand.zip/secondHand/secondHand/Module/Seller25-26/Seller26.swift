//
//  Seller26.swift
//  secondHand
//
//  Created by karen syah on 18/07/22.
//

import SwiftUI

struct Seller26: View
{
    var body: some View
    {
        NavigationView
        {
        VStack
        {
            HStack
            {
                Image("IU")
                    .resizable()
                    .frame(width: 50, height: 50, alignment: .leading)
                    .cornerRadius(12.0)
                    .scaledToFit()
            
                VStack (alignment: .leading, spacing: 4)
                {
                    Text("Lee Ji-eun")
                        .font(.custom("Poppins-SemiBold", size: 14))
                        .frame(alignment: .topTrailing)
                    Text("Songjeong-dong, Seoul")
                        .font(.custom("Poppins", size: 10))
                        .foregroundColor(.secondary)
                        .frame(alignment: .topTrailing)
                }
                Spacer()
            }
            .padding()
            .frame(maxWidth: 328, maxHeight: 80)
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 1)
        
            HStack
            {
                Text("Daftar Produkmu yang Ditawar")
                    .font(.custom("Poppins-SemiBold", size: 14))
                    .frame(alignment: .topTrailing)
                    .padding()
                Spacer()
            }
            
            HStack
            {
                VStack (alignment: .leading, spacing: 4)
                {
               
                Image("casio_1")
                    .resizable()
                    .frame(width: 50, height: 50, alignment: .leading)
                    .cornerRadius(12.0)
                    .scaledToFit()
                Spacer()
                }
                
                VStack (alignment: .leading, spacing: 4)
                {
                    Text("Penawaran Produk")
                        .font(.custom("Poppins", size: 10))
                        .foregroundColor(.secondary)
                        .frame(alignment: .topTrailing)
                    Text("Jam Tangan Casio")
                        .font(.custom("Poppins-Light", size: 14))
                        .frame(alignment: .topTrailing)
                    Text("Rp. 250.000")
                        .font(.custom("Poppins-Light", size: 14))
                        .frame(alignment: .topTrailing)
                    Text("Ditawar Rp. 200.000")
                        .font(.custom("Poppins-Light", size: 14))
                        .frame(alignment: .topTrailing)
                    Spacer()
                }
                Spacer()
                
                HStack
                {
                    VStack (alignment: .leading, spacing: 4)
                    {
                        Text("20 Apr, 14:04")
                            .font(.custom("Poppins", size: 10))
                            .foregroundColor(.secondary)
                            .frame(alignment: .top)
                        Spacer()
                    }
                }
                
                
            }
            .frame(maxWidth: .infinity, maxHeight: 86)
            .padding()
            
            HStack
            {
                Button(action: {})
                {
                    Image("Status")
                        .resizable()
                        .frame(width: 156, height: 36, alignment: .leading)
                        .cornerRadius(12.0)
                        .scaledToFit()
                }
                
                Button(action: {})
                {
                    Image("Hubungi")
                        .resizable()
                        .frame(width: 156, height: 36, alignment: .leading)
                        .cornerRadius(12.0)
                        .scaledToFit()
                }
                
            }
            
            HStack
            {
                
                VStack (alignment: .leading, spacing: 4)
                {
               
                Image("Samsung")
                    .resizable()
                    .frame(width: 50, height: 50, alignment: .leading)
                    .cornerRadius(12.0)
                    .scaledToFit()
                Spacer()
                }
                
                VStack (alignment: .leading, spacing: 4)
                {
                    Text("Penawaran Produk")
                        .font(.custom("Poppins", size: 10))
                        .foregroundColor(.secondary)
                        .frame(alignment: .topTrailing)
                    Text("Smartwatch Samsung Galaxy Pro S...")
                        .font(.custom("Poppins-Light", size: 14))
                        .frame(alignment: .topTrailing)
                    Text("Rp. 3.550.000")
                        .font(.custom("Poppins-Light", size: 14))
                        .frame(alignment: .topTrailing)
                    Text("Ditawar Rp. 2.000.000")
                        .font(.custom("Poppins-Light", size: 14))
                        .strikethrough()
                        .frame(alignment: .topTrailing)
                    Spacer()
                }
                Spacer()
                
                HStack
                {
                    VStack (alignment: .leading, spacing: 4)
                    {
                        Text("1 Apr, 09:08")
                            .font(.custom("Poppins", size: 10))
                            .foregroundColor(.secondary)
                            .frame(alignment: .top)
                        Spacer()
                    }
                }
                
                
            }
            
            .frame(maxWidth: .infinity, maxHeight: 86)
            .padding()
            .background(Color.white)
            .shadow(radius: 1)
            Spacer()
        }
        .navigationBarTitle("Info Penawar", displayMode: .inline)
    }
}
}

struct Seller26_Previews: PreviewProvider {
    static var previews: some View {
        Seller26()
            .previewInterfaceOrientation(.portrait)
    }
}
