//
//  RegisterViewController.swift
//  secondHand
//
//  Created by nurin berlianna on 15/06/22.
//

import UIKit
import Alamofire
import SwiftUI

class RegisterViewController: UIViewController {

    @IBOutlet weak var UIbuttonShowHideText: UIButton!
    @IBOutlet weak var UIButtonGoToLogin: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UIbuttonShowHideText.setTitle("", for: .normal)

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func rgName(_ sender: UITextField) {
        print("value pwd \(String(describing: sender.text))")
    }
    
    @IBAction func rgEmail(_ sender: UITextField) {
        print("value pwd \(String(describing: sender.text))")
    }
    
    @IBAction func rgPass(_ sender: UITextField) {
        print("value pwd \(String(describing: sender.text))")
    }
    
    @IBAction func btnRegist(_ sender: Any) {
        let vc = UIHostingController(rootView: ContentView())
        self.navigationController?.pushViewController(vc, animated: true)

    }
    
    @IBAction func goToLogin(_ sender: Any) {
        let vc = StartMenuVC();
        let transition = CATransition()
           transition.duration = 0.5
           transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeInEaseOut)
           transition.type = CATransitionType.push
           transition.subtype = CATransitionSubtype.fromLeft
           navigationController?.view.layer.add(transition, forKey: kCATransition)
        self.navigationController?.pushViewController(vc, animated: true)
    }
    


}
