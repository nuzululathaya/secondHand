//
//  SHTabBar.swift
//  Latihan
//
//  Created by Nuzulul Athaya on 16/06/22.
//

import UIKit

class SHTabBar: UITabBarController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupTabbarView()
//        setupNavigationVC()
    }
    
        func setupTabbarView() {
            view.backgroundColor = .systemBackground
            tabBar.barTintColor = .systemBackground
            tabBar.tintColor = .purple
            
        }
//
//            func setupNavigationVC() {
//            let homeViewController = HomeViewController()
//            homeViewController.tabBarItem = UITabBarItem(
//                title: "Home",
//                image: UIImage(named: "Vector"),
//                selectedImage: UIImage(named: "Vector")
//            )
//
//            let notifikasiViewController = NotifikasiViewController()
//            notifikasiViewController.tabBarItem = UITabBarItem(
//                title: "Notifikasi",
//                image: UIImage(named: "fi_bell"),
//                selectedImage: UIImage(named: "fi_bell")
//            )
//
//            let jualViewController = JualViewController()
//            jualViewController.tabBarItem = UITabBarItem(
//                title: "Jual",
//                image: UIImage(named: "fi_plus-circle"),
//                selectedImage: UIImage(named: "fi_plus-circle")
//            )
//
//            let daftarJualViewController = DaftarJualViewController()
//            daftarJualViewController.tabBarItem = UITabBarItem(
//                title: "Daftar Jual",
//                image: UIImage(named: "fi_list"),
//                selectedImage: UIImage(named: "fi_list")
//            )
//
//            let akunViewController = AkunViewController()
//            akunViewController.tabBarItem = UITabBarItem(
//                title: "Akun",
//                image: UIImage(named: "fi_user"),
//                selectedImage: UIImage(named: "fi_user")
//
//            )
                

//
//            let _viewControllers: [UINavigationController] = [
//                homeViewController,
//                notifikasiViewController,
//                jualViewController,
//                daftarJualViewController,
//                akunViewController].map {
//
//                let navigationController = UINavigationController(rootViewController: $0)
//                navigationController.setNavigationBarHidden(false, animated: false)
//                return navigationController
//            }
//
//                viewControllers = _viewControllers
//        }
}
