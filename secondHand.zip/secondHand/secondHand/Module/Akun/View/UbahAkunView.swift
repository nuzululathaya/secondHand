//
//  UbahAkunView.swift
//  secondHand
//
//  Created by Nuzulul Athaya on 04/07/22.
//

import SwiftUI

struct UbahAkunView: View {
    var body: some View {
        ScrollView {
        VStack {
        ProfileImage()
        FormField()
        }
        Button(action: {print("Berhasil Disimpan")}){
            ButtonSimpan()
            
            }
        }
    }
}

struct UbahAkunView_Previews: PreviewProvider {
    static var previews: some View {
        UbahAkunView()
    }
}


struct ProfileImage: View {
    var body: some View {
        Button(action: {}) {
           Image("image")
               .resizable()
               .frame(width: 96, height: 96)
               .aspectRatio(contentMode: .fit)
               .cornerRadius(5.0)
               
               }
        }
    
}

struct FormField: View {
    
    @State var namaAkun: String = ""
    @State var kota: String = ""
    @State var alamat: String = ""
    @State var number: String = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            
            VStack(alignment: .leading, spacing: 4) {
                
                Text("Nama*")
                    .font(.custom("Poppins-Regular", size: 12))
                    
                
                TextField("Nama", text: $namaAkun)
                    .font(.custom("Poppins-Regular", size: 14))
                    .padding()
                    .background(Color.white)
                    .cornerRadius(16.0)
                    .shadow(radius: 1)
                
            }
            VStack(alignment: .leading, spacing: 4) {
                Text("Kota*")
                    .font(.custom("Poppins-Regular", size: 12))
                
                TextField("Pilih Kota", text: $kota)
                    .font(.custom("Poppins-Regular", size: 14))
                    .padding()
                    .background(Color.white)
                    .cornerRadius(16.0)
                    .shadow(radius: 1)
                
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Alamat")
                    .font(.custom("Poppins-Regular", size: 12))
                
                TextField("Contoh: Jalan Ikan Hiu 33", text: $alamat)
                    .font(.custom("Poppins-Regular", size: 14))
                    .padding()
                    .background(Color.white)
                    .cornerRadius(16.0)
                    .shadow(radius: 1)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("No Handphone*")
                    .font(.custom("Poppins-Regular", size: 12))
                
                TextField("contoh: +628123456789", text: $number)
                    .font(.custom("Poppins-Regular", size: 14))
                    .padding()
                    .background(Color.white)
                    .cornerRadius(16.0)
                    .shadow(radius: 1)
            }
        }
        .frame(maxWidth: .infinity)
        .padding()
    }
}

struct ButtonSimpan: View {
    var body: some View {
        Button(action: {}) {
            Image("Simpan")
                .resizable()
                .frame(maxWidth: 328, maxHeight: 48)
        }
    }
}
