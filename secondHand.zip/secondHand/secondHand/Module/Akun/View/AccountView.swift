//
//  AccountView.swift
//  secondHand
//
//  Created by Nuzulul Athaya on 30/06/22.
//

import SwiftUI

struct AccountView: View {
    
    var body: some View {
    
        NavigationView {
        ScrollView {
                VStack {
                
                Spacer ()
                VStack {
                Button(action: {}) {
                Image("image")
                    .resizable()
                    .frame(width: 125, height: 125, alignment: .top)
                    .aspectRatio(contentMode: .fit)
                    .ignoresSafeArea(.all)
                    .edgesIgnoringSafeArea(.top)
                    .cornerRadius(5.0)
                    
                    }
                }
                .padding()
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                .padding()
                
            VStack (alignment: .leading, spacing: 10){
                HStack {
                    NavigationLink(destination: UbahAkunView()) {
                
                    Image("fi_edit-3")
                        .resizable()
                        .frame(width: 20, height: 20)
                        .cornerRadius(5.0)
                   
                        Text("Ubah Akun")
                            .font(.custom("Poppins-Medium", size: 14))
                            .padding()
                            .background(Color(.white))
                            .cornerRadius(10.0)
                            .foregroundColor(.black)
                
            }
        }
                
            HStack {

                NavigationLink(destination: SettingScreen()) {
                    Image("fi_settings")
                        .resizable()
                        .frame(width: 20, height: 20)
                        .cornerRadius(5.0)
                  
                        Text("Pengaturan Akun")
                            .font(.custom("Poppins-Medium", size: 14))
                            .padding()
                            .background(Color(.white))
                            .cornerRadius(10.0)
                            .foregroundColor(.black)
           
                }
                    
            }
            
            HStack {

                Button(action: {}) {
                    Image("fi_log-out")
                        .resizable()
                        .frame(width: 20, height: 20)
                        .cornerRadius(5.0)
                    
                        Text("Keluar")
                            .font(.custom("Poppins-Medium", size: 14))
                            .padding()
                            .background(Color(.white))
                            .cornerRadius(10.0)
                            .foregroundColor(.black)
                            
                }
            }
        }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
                
                
            VStack (alignment: .center) {
                    Text("Version 1.0.0")
                    .foregroundColor(.gray)
                               
                Spacer()

                    }
                }
            }
        .navigationTitle("Akun Saya")
        }
    }
}
    

struct AccountView_Previews: PreviewProvider {
    static var previews: some View {
        AccountView()
            .previewInterfaceOrientation(.portrait)
    }
}





