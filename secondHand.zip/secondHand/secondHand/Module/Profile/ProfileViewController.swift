//
//  ProfileViewController.swift
//  secondHand
//
//  Created by Nuzulul Athaya on 27/06/22.
//

import UIKit

class ProfileViewController: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Profile"
        view.backgroundColor = .systemBackground
        
    }
}
