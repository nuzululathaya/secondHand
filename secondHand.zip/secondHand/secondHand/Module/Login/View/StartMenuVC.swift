//
//  StartMenuVC.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 10/04/22.
//

import UIKit
import Alamofire
import SwiftUI

// MARK: Set Up Button
class StartMenuVC: UIViewController {
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var UITextEmail: UITextField!
    @IBOutlet weak var UITextPassword: UITextField!
    @IBOutlet weak var showHidePwd: UIButton!
    
    var iconClick: Bool!
    //    let interactor = StartMenuInteractor()
    let presenter: StartMenuPresenter = StartMenuPresenter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UITextEmail.text = "johndoe@mail.com"
        UITextPassword.text = "123456"
        UITextPassword.isSecureTextEntry = true
        iconClick = true
    }
    
    @IBAction func showHidepwd(_ sender: Any) {
        if(iconClick == true) {
            UITextPassword.isSecureTextEntry = false
        } else {
            UITextPassword.isSecureTextEntry = true
        }

        iconClick = !iconClick
    }
    @IBAction func pwdDidChanged(_ sender: UITextField) {
        print("value pwd \(String(describing: sender.text))")
    }
    
    @IBAction func loginDIdChanged(_ sender: UITextField) {
        print("value pwd \(String(describing: sender.text))")
    }
    
    
    @IBAction func btnLoginTap(_ sender: Any) {
        
        let params: Parameters = [
            "email": UITextEmail.text ?? "",
            "password": UITextPassword.text ?? ""
           ]
        
        presenter.didLogin(params: params)
        let vc = UIHostingController(rootView: ContentView())
//        present(vc, animated: true)
        self.navigationController?.pushViewController(vc, animated: true)
        
           
       
    }
     
    
    func succeed(_ response: LoginResponse) {
        print(response)
    }

    func failed() {
        print("Failed..")
    }
    
    @IBAction func pushToRegister(_ sender: Any) {
        let vc = RegisterViewController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    


}


// MARK: Presenter to View
extension StartMenuVC: PTVStartMenu{
    
}
