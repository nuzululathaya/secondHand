//
//  StartMenuProtocol.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 10/04/22.
//

import Foundation
import UIKit

protocol PTVStartMenu: AnyObject {
    
}

protocol ITPStartMenu: AnyObject {
    
}

protocol PTIStartMenu: AnyObject {
    var presenter: ITPStartMenu? {get set}
    
}

protocol VTPStartMenu: AnyObject {
    var view: PTVStartMenu? {get set}
    var interactor: PTIStartMenu? {get set}
    var router: PTRStartMenu? {get set}
    
    func goToLogin(nav: UINavigationController)
    func goToRegister(nav: UINavigationController)
    func placesListFetched(places: LoginResponse)
}

protocol PTRStartMenu: AnyObject {
    static func createStartMenuModule() -> StartMenuVC
    func pushToLogin(nav: UINavigationController)
    func pushToRegister(nav: UINavigationController)
    
}

protocol PlaceListStartMenuProtocolInput: AnyObject {
//    var output:
}

protocol PlaceListStartMenuProtocolOutput: AnyObject {
    func didLoginSuccess(PersonalInfo: PersonalInfo)
}

