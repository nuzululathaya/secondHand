//
//  StartMenuPresenter.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 10/04/22.
//

import Foundation
import UIKit
import Alamofire

class StartMenuPresenter {
    
    var view: PTVStartMenu?
    var interactor: loginInteractorInputProtocol?
    
    
    var router: PTRStartMenu?
    
    init(){
        self.interactor = StartMenuInteractor()
    }
    
    func goToLogin(nav: UINavigationController) {
        router?.pushToLogin(nav: nav)
    }
    
    func goToRegister(nav: UINavigationController) {
        router?.pushToRegister(nav: nav)
    }
    
    func didLogin(params: Parameters) {
        interactor?.requestLogin(params: params)
        
    }
    
}

extension StartMenuPresenter: loginInteractorOutputProtocol {
    func requestLoginDidSuccess(response: PersonalInfo) {
        print("masuk sini")
        print("result from response \(response)")
    }
    
    func requestLoginDidFailed(message: String) {
        print("error response \(message)")
    }
    
    
}


extension StartMenuPresenter: ITPStartMenu, PlaceListStartMenuProtocolOutput{
    func didLoginSuccess(PersonalInfo: PersonalInfo) {
        
    }
    
    
}
