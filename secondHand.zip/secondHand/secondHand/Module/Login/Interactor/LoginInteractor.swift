//
//  StartMenuInteractor.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 10/04/22.
//

import Foundation

class StartMenuInteractor: PTIStartMenu {
    var presenter: ITPStartMenu?
    
    
}
