//
//  StartMenuInteractor.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 10/04/22.
//

import Foundation
import Alamofire

protocol loginInteractorOutputProtocol: class {
    func requestLoginDidSuccess(response: PersonalInfo)
    func requestLoginDidFailed(message: String)
}

protocol loginInteractorInputProtocol: class{
    var output: loginInteractorOutputProtocol? {set get}
    func requestLogin(params: Parameters)
}


final class StartMenuInteractor: loginInteractorInputProtocol {
    var presenter: ITPStartMenu?
    var output: loginInteractorOutputProtocol?
    
    func requestLogin(params: Parameters) {
        AF.request("https://market-final-project.herokuapp.com/auth/login", method: .post, parameters: params, encoding: JSONEncoding.default, headers: nil).validate(statusCode: 200 ..< 299).responseData { response in
            switch response.result {
                case .success(let data):
                let decoder = JSONDecoder()
                    do {
                        guard let jsonObject = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                            print("Error: Cannot convert data to JSON object")
                            return
                        }
                        guard let prettyJsonData = try? JSONSerialization.data(withJSONObject: jsonObject, options: .prettyPrinted) else {
                            print("Error: Cannot convert JSON object to Pretty JSON data")
                            return
                        }
                        guard let prettyPrintedJson = String(data: prettyJsonData, encoding: .utf8) else {
                            print("Error: Could print JSON in String")
                            return
                        }
                        
                        let data = try decoder.decode(PersonalInfo.self, from: prettyJsonData)
                        
                        

                        self.output?.requestLoginDidSuccess(response: data)
                        UserDefaults.standard.set(data.access_token, forKey: "access_token")
                
                        print(prettyPrintedJson)
                    } catch {
                        print("Error: Trying to convert JSON data to string")
                        return
                    }
                case .failure(let error):
                    print(error)
            }
        }
    }
    
}
