//
//  StartMenuEntity.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 10/04/22.
//

import Foundation

// empty
 class LoginResponse: Codable {
    var response: VenuesList
}


final class VenuesList: Codable {
    let PersonalInfo: PersonalInfo
}


final class PersonalInfo: Codable {
    let id : Int
    let name: String
    let email: String
    let access_token : String
}

final class Categories: Decodable {
    let id: String
    let name: String
}

final class Location: Decodable {
    let lat: Double
    let lng: Double
    let city: String?
    let state: String?

    var address: String? {
        get {
            return "\(city ?? ""), \(state ?? "")"
        }
     }
}
