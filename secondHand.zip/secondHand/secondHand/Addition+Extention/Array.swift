//
//  Array.swift
//  secondHand
//
//  Created by Prana Apsara Wijaya on 01/07/22.
//

import Foundation


extension Array {
    func splitIntothree() -> [[Element]] {
        let ct = self.count
        let half = ct / 3
        let leftSplit = self[0 ..< half]
        let rightSplit = self[half ..< ct]
        return [Array(leftSplit), Array(rightSplit)]
    }
}
